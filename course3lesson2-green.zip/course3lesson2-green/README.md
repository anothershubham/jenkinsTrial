These are the course files from Udacity Course 3 Lesson 2 Cloud DevOps Nanodegree
